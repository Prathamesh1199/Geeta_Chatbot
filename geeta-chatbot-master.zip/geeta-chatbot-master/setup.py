from setuptools import find_packages, setup

setup(
    name = 'Geeta Chatbot',
    version= '0.0.0',
    author= 'Reenal Boddul',
    author_email= 'reenalboddul@gmail.com',
    packages= find_packages(),
    install_requires = []

)